# coding: utf-8
 
from tkinter import * 

fenetre = Tk()

label = Label(fenetre, text="bonjour les gars")
label.pack()

label1 = Label(fenetre, text="bonjour les matcho")
label.pack()


fenetre.mainloop()
