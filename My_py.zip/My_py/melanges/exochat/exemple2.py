# coding: utf-8
 
from tkinter import * 

fenetre = Tk()
def affiche():
    label.config(fenetre, text="le noir appuyer sur le bouton",command=affiche()) 
label = Label(fenetre, text="salut")
label.pack()
label.configure(fenetre, text="le noir a appuyer sur le bouton",command=affiche) 
label1 = Button(fenetre, text="Button 1",command=affiche) 
label1.pack()
fenetre.mainloop()
