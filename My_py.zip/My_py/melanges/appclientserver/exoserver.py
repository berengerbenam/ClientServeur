import socket
socket_ecoute = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket_ecoute.bind(('127.0.0.1', 63000))
socket_ecoute.listen(5)
while True:
    client, infoclient = socket_ecoute.accept()
    adresseIP = infoclient[0]
    port = str(infoclient[1])
    print("Message reçu du client " + adresseIP + ":" + port )
    donnees=client.recv(255).decode("utf-8")
    print(donnees) 
    donnees1=donnees + '\nPrésent !'
    client.send(donnees1.encode("utf-8"))
    client.close()

socket_ecoute.close()
