import socket
connexion_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
adresseIP = "127.0.0.1"	# Ici, le poste local
port = 63000
connexion_serveur.connect((adresseIP, port))
print("Connecté au serveur")
print("Tapez un message a envoyer au serveur. ")
message = input("> ")
connexion_serveur.send(message.encode("utf-8"))
reponse = connexion_serveur.recv(255)
print(reponse.decode("utf-8"))
print("Connexion fermée")
connexion_serveur.close()

