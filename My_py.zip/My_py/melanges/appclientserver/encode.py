a="toto tape nama"
print(a.encode("utf-8"))

