# coding: utf-8
from tkinter import *
from tkinter.messagebox import *

if askyesno('Titre 1', 'Êtes-vous sûr de vouloir faire ça?'):
    showwarning('Titre 2', 'Tant pis...')
else:
    showinfo('Titre 3', 'Vous avez peur!')
    showerror("Titre 4", "Aha")


