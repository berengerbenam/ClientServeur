# coding: utf-8
from tkinter import *
from tkinter.filedialog import *
fenetre = Tk()
filepath = askopenfilename(title="Ouvrir une image",filetypes=[('png files','.png'),('all files','.*')])
photo = PhotoImage(file=filepath)
canvas = Canvas(fenetre, width=photo.width(), height=photo.height(), bg="yellow")
canvas.create_image(600, 400, anchor=CENTER, image=photo)
canvas.pack()

fenetre.mainloop()

