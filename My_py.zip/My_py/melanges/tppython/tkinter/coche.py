# coding: utf-8
from tkinter import *
fenetre = Tk()
bouton = Checkbutton(fenetre, text="Nouveau?")
bouton.pack()
fenetre.mainloop()

