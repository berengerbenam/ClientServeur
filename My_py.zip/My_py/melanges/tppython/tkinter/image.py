# coding: utf-8
from tkinter import *
from tkinter.messagebox import *
fenetre = Tk()
photo = PhotoImage(file="costume.png")
canvas = Canvas(fenetre,width=1200, height=1200)
canvas.create_image(600,400,anchor=CENTER, image=photo)
canvas.pack()
fenetre.mainloop()

