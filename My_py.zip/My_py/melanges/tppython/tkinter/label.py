# coding: utf-8
from tkinter import *
fenetre = Tk()
label = Label(fenetre, text="Texte par défaut", bg="yellow")
label.pack()
fenetre.mainloop()

