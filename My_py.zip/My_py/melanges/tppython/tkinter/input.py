# coding: utf-8
from tkinter import *
fenetre = Tk()
value = StringVar() 
value.set("texte par défaut")
entree = Entry(fenetre, textvariable=value, width=30)
entree.pack()
fenetre.mainloop()

