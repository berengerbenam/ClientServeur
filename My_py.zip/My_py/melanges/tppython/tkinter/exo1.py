# coding: utf-8
from tkinter import *
fenetre = Tk()
label = Label(fenetre, text="Bonjour a  tous")
label.pack()
fenetre.mainloop()

