# coding: utf-8
from tkinter import *
fenetre = Tk()
scrollbar = Scrollbar(fenetre)  
def choix1():
    return('Bouton 1')
def choix2():
        return('Bouton 2')
def choix():
        liste.insert(1, choix1())
def mhoix():
            liste.insert(1, choix2())




    


    
    
Button(fenetre, text ='Bouton 1',command=choix).pack(side=LEFT, padx=5, pady=5)
Button(fenetre, text ='Bouton 2',command=mhoix).pack(side=RIGHT, padx=5, pady=5)
liste = Listbox(fenetre)
liste.pack()
fenetre.mainloop()

