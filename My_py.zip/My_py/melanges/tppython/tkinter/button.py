# coding: utf-8
from tkinter import *
fenetre = Tk()
bouton=Button(fenetre, text="Fermer", command=fenetre.quit)
bouton.pack()
fenetre.mainloop()

