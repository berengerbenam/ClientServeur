# coding: utf-8
from tkinter import *
from tkinter.messagebox import *
fenetre = Tk()
def recupere():
    showinfo("Alerte" , "Hôte " + HOST.get() + " port " + PORT.get())

Frame1 = Frame(fenetre,borderwidth=2,relief=GROOVE)
Label(Frame1, text = "Hôte").grid(row=0,column=0,padx=5,pady=5,sticky=W)

HOST = StringVar()
HOST.set("localhost")
Entry(Frame1, textvariable=HOST).grid(row=0,column=1,padx=5,pady=5,sticky=W)

Label(Frame1, text = "Hôte").grid(row=1,column=0,padx=5,pady=5,sticky=W)
PORT = StringVar()
PORT.set("10000")
Entry(Frame1, textvariable=PORT).grid(row=1,column=1,padx=5,pady=5,sticky=W)

ButtonConnexion = Button(Frame1, text ='Ouvrir le serveur',command=recupere)
ButtonConnexion.grid(row=0,column=2,rowspan=2,padx=5,pady=5)
Frame1.grid(row=0,column=0,padx=5,pady=5,sticky=W+E)



fenetre.mainloop()

