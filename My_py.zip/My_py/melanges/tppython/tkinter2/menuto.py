from tkinter import *  
root = Tk()  
root.geometry("200x200")  
                              
def open():
    top = Toplevel(root)  
    label1=Label(top,text="Votre nom est" + entree.get())
    label1.place(x=0,y=0)
    top.mainloop()  
label=Label(root,text="Votre nom :")
label.place(x=0,y=20)
entree=Entry(root,textvariable=StringVar())
entree.place(x=80,y=20)
btn = Button(root, text = "open", command = open)                                                      
btn.place(x=75,y=50)
root.mainloop()  
