from tkinter import *
app = Tk()
def voir():
    del(entry_mdp['show']) 
entry_user = Entry(app, textvariable=StringVar())
entry_mdp = Entry(app, textvariable=StringVar(), show="*")
bouton=Button(app,text="Voir mdp",command=voir)
entry_user.pack()
entry_mdp.pack()
bouton.pack()
app.mainloop()


