from tkinter import * 
from bibchat import *
fen = Tk()  
fen.geometry("200x200")  
                              
def open():
    chatroom(entree.get())

label=Label(fen,text="Votre nom :")
label.place(x=0,y=20)
entree=Entry(fen,textvariable=StringVar())
entree.place(x=80,y=20)
btn = Button(fen, text = "open", command = open)                                                      
btn.place(x=75,y=50)
fen.mainloop()  
