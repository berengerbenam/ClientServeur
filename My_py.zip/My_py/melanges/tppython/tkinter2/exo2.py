from tkinter import *
root = Tk()
my_entry = Entry(root)
my_entry.pack(padx=20, pady=20)
my_entry.focus_set()
root.mainloop()
