import socket
import threading 
threadsClients = []
adresseIP = "127.0.0.1"
port=50000
def instanceServeur (client, infosClient,message):
    adresseIP = infosClient[0]
    port = str(infosClient[1])
    while message.upper() != "FIN":
        message = input("> ")
        client.send(message.encode("utf-8"))
        reponse = client.recv(255)
        print(reponse.decode("utf-8"))
    client.close()
serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    serveur.connect((adresseIP, port))
    print("Connecté au serveur")
    print("Tapez FIN pour terminer la conversation. ")
    message = ""
    while (message.upper()!="FIN"):
        message = input("> ")
        serveur.send(message.encode("utf-8"))
        reponse = serveur.recv(255)
        print(reponse.decode("utf-8"))
    serveur.close()
except:
    serveur.bind(('', 50000))	# Écoute sur le port 50000
    serveur.listen(5)
    print("Connecté")
    print("Tapez FIN pour terminer la conversation. ")
    message = input("> ")
    while True:
        client, infosClient = serveur.accept()
        threadsClients.append(threading.Thread(None, instanceServeur, None, (client, infosClient,message), {}))
        threadsClients[-1].start()
    serveur.close()
